export function KeywordListRecipe () {
  return {
    tagName: "datalist",
    attrs: {
      id: "keyword-list",
    },
  };
};