import { Component } from "./Component.js";

export class Footer extends Component {
  constructor(component) {
    super();
    this.restructure(component);
  }
}
