// entry-server.ts
export async function render(url: string): Promise<string> {
  return ``;
}
