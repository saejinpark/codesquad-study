export interface ArticleData {
  link: string;
  content: string;
  hasImg: boolean;
  img: string;
}