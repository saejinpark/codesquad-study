import { View } from "../constants/View";

export type ViewType = keyof typeof View
