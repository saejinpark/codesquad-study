type TextContent = string;
