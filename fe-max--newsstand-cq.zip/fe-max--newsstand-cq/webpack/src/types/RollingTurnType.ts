import { RollingTurn } from "../constants/RollingTurn";

export type RollingTurnType = RollingTurn.LEFT | RollingTurn.RIGHT;
