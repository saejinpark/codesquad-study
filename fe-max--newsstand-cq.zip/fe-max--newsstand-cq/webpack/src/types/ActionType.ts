export type Action = "updateTime" | "";
