export type Callback = (...args: any[]) => any;
