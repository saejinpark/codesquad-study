import { IEventFunction } from "../interfaces/IEventFunction";
import { Callback } from "./Callback";

export type Prop = [string, string | Callback];
