import { TagNames } from "../constants/TagNames";

export type TagName = keyof typeof TagNames;
