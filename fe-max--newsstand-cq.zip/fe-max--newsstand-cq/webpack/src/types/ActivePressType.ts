import { ActivePress } from "../constants/ActivePress";

export type ActivePressType = keyof typeof ActivePress;
