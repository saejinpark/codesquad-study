export enum View {
  GRID,
  LIST,
}
