export enum RollingTurn {
  LEFT,
  RIGHT
}