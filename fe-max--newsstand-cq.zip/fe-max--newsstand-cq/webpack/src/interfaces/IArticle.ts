export interface IArticle {
  link: string;
  content: string;
  hasImg: boolean;
  img: string;
}
