export interface IEventFunction {
  (e?: Event): void;
}
