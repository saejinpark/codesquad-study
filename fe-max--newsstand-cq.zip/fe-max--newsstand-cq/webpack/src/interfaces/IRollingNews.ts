import { IRollingNewsItem } from "./IRollingNewsItem";

export interface IRollingNews extends Array<IRollingNewsItem> {}
