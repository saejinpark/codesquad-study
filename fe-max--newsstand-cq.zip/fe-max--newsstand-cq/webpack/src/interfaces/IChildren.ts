import { IFakeElement } from "./IFakeElement";

export interface IChildren extends Array<IFakeElement> {}
