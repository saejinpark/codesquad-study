export interface IRollingNewsItem {
  href: string;
  textContent: string;
}
