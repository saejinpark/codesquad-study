export interface ITabData {
  name: string,
  index: number,
  limit: number,
}