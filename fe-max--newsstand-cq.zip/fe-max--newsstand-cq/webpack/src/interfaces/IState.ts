export interface IState extends Record<string, any> {}
