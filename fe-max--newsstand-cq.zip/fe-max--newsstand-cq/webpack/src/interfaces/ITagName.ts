import { TagNames } from "../constants/TagNames";

export type ITagName = keyof typeof TagNames;
