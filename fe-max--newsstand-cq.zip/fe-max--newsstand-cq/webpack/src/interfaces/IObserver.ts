import { Callback } from "../types/Callback";

export interface IObserver extends Array<Callback> {}
