import { IPress } from "./IPress";

export interface INews {
  [category: string]: IPress[];
}
