export const Config = {
  API_URL: "http://localhost:5173/api/",
  YNA_URL: "https://www.yna.co.kr/",
  GRID_ROW: 4,
  GRID_COL: 6,
};
